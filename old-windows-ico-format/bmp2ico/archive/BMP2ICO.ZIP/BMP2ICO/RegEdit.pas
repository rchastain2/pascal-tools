unit RegEdit;

{ Save 20Ko in your applications with RegEdit in place of Registry ! }
{ By Paul TOTH <tothpaul@free.fr> }
{ http://tothpaul.free.fr }

interface

Uses
 Windows;

Function WriteRegString(Key:HKEY;Path:string;Value,Data:string):boolean;
Function WriteRegStrings(Key:HKEY;Path:string;Values:array of string):boolean;
Function ReadRegString(Key:HKEY;Path:string;Value,Default:string):string;
Function DeleteRegString(Key:HKEY;Path:string;Value:string):boolean;

Procedure SetFileType(Extension,Description,Application:string);

implementation

Function WriteRegString(Key:HKEY;Path:string;Value,Data:string):boolean;
 Var
  Handle:HKEY;
  Disposition:integer;
 begin
  Result:=(RegCreateKeyEx(Key,pchar(Path),0,nil,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,nil,Handle,@Disposition)=ERROR_SUCCESS);
  if Result then begin
   Result:=(RegSetValueEx(Handle,pchar(Value),0,REG_SZ,pchar(Data),Length(Data))=ERROR_SUCCESS);
   RegCloseKey(Handle);
  end;
 end;

Function WriteRegStrings(Key:HKEY;Path:string;Values:array of string):boolean;
 Var
  Handle:HKEY;
  Disposition:integer;
  i:integer;
  Value,Data:string;
  p:integer;
 begin
  Result:=(RegCreateKeyEx(Key,pchar(Path),0,nil,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,nil,Handle,@Disposition)=ERROR_SUCCESS);
  if Result then begin
   for i:=Low(Values) to High(Values) do begin
    Value:=Values[i];
    p:=pos('=',Value);
    Data:=Copy(Value,p+1,Length(Value));
    SetLength(Value,p-1);
    Result:=Result and (RegSetValueEx(Handle,pchar(Value),0,REG_SZ,pchar(Data),Length(Data))=ERROR_SUCCESS);
   end;
   RegCloseKey(Handle);
  end;
 end;

Function ReadRegString(Key:HKEY;Path:string;Value,Default:string):string;
 Var
  Handle:HKEY;
  RegType:integer;
  DataSize:integer;
 begin
  Result:=Default;
  if (RegOpenKeyEx(Key,pchar(Path),0,KEY_ALL_ACCESS,Handle)=ERROR_SUCCESS) then begin
   if RegQueryValueEx(Handle,pchar(Value),nil,@RegType,nil,@DataSize)=ERROR_SUCCESS then begin
    SetLength(Result,Datasize);
    RegQueryValueEx(Handle,pchar(Value),nil,@RegType,PByte(pchar(Result)),@DataSize);
    SetLength(Result,Datasize-1);
   end;
   RegCloseKey(Handle);
  end;
 end;

Function DeleteRegString(Key:HKEY;Path:string;Value:string):boolean;
 Var
  Handle:HKEY;
 begin
  Result:=(RegOpenKeyEx(Key,pchar(Path),0,KEY_ALL_ACCESS,Handle)=ERROR_SUCCESS);
  if Result then begin
   Result:=(RegDeleteValue(Handle,pchar(Value))=ERROr_SUCCESS);
   RegCloseKey(Handle);
  end;
 end;

Procedure SetFileType(Extension,Description,Application:string);
 var
  ext:string;
  dsc:string;
  exe:string;
 begin
  ext:='.'+Extension;
  dsc:=ReadRegString(HKEY_CLASSES_ROOT,ext,'','');
  if dsc='' then begin
   dsc:=Extension+'Files';
   WriteRegString(HKEY_CLASSES_ROOT,ext,'',dsc);
   WriteRegString(HKEY_CLASSES_ROOT,dsc,'',Description);
  end;
  ext:=ReadRegString(HKEY_CLASSES_ROOT,dsc+'\DefaultIcon','','');
  if ext='' then WriteRegString(HKEY_CLASSES_ROOT,dsc+'\DefaultIcon','',Application+',0');
  exe:='"'+Application+'" "%1"';
  ext:=ReadRegString(HKEY_CLASSES_ROOT,dsc+'\Shell\Open\Command','','');
  if (ext='') then
   WriteRegString(HKEY_CLASSES_ROOT,dsc+'\Shell\Open\Command','',exe)
  else
   if (ext<>exe) then begin
    WriteRegString(HKEY_CLASSES_ROOT,dsc+'\Shell\MySoft','',Description);
    WriteRegString(HKEY_CLASSES_ROOT,dsc+'\Shell\MySoft\Command','',exe);
   end;
 end;
end.
